package com.company;

public class Node{
    Node parent; //родитель узла
    Node child; //непосредственный ребенок узла
    Node sibling; //"сводный узел"_ с ним есть общий родительский узел
    int value; //информация, хранящаяся в узле
    //static int count;
    Node(int a){
        value = a;
        child= parent = sibling = null;
    }
    Node(){
        child= parent = sibling = null;
    }

    public void addChild(Node value){
        Node current = this;
        if (current.child != null) {
            current = current.child;
            while (current.sibling != null) {
                current = current.sibling;
            }
            current.sibling = value;
            current.sibling.parent = current.parent;
            current = current.sibling;
            current.child = null;
            current.sibling = null;
        }
        else {
            current.child = value;
            current.child.parent = current;
            current = current.child;
            current.child = null;
            current.sibling = null;
        }
    }

    public Node getParent(){
        return this.parent;
    }

    public List path(){
        Node cur = this;
        if(cur.parent == null)
            return null;
        List path = new List();
        path.add(cur.value);
        path.add(cur.parent.value);
        return path;
    }

    public int size(){
        int s = 0;
        Node current = this;
        Tree tree = new Tree(this);
        List list = tree.toList();
        return list.size();
    }

    public Node getChild(int index){
        int i = 0;
        Node cur = this.child;
        while(i < index){
            if(cur.sibling != null){
                i++;
                cur = cur.sibling;
            }
            else
                return null;
        }
        return cur;
    }

    public Tree subtree(){
        if(this.child == null)
            return null;
        Tree tr = new Tree();
        tr.tree = this.child;
        return tr;
    }

    public Node findParent(Node another){
        int i = 0;
        Node par = another;
        Node cur, curr;
        cur = this.parent;
        while(par != null){
            par = par.parent;
            curr = cur;
            while(curr != null){
                if(curr.equals(par)){
                    return curr;
                }
                curr = curr.parent;
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        return (this == obj);
    }

    public boolean removeChild(Node value){
        Node del = value, ch = value.child, cur = value;

        if(!this.equals(cur.parent)) //проверим, что такой ребенок вообще есть
            return false;
        if(cur.sibling != null){
            System.out.println(cur.sibling.value);
            cur.child = cur.sibling.child;
            cur.value = cur.sibling.value;
            cur.sibling = cur.sibling.sibling;
            while(cur.sibling != null){
                System.out.println(cur.value);
                cur = cur.sibling;
            }
            System.out.println(cur.value);
            if(ch != null){
                ch.parent = cur.parent;
                cur.sibling = ch;
            }
        }
        else if(del.child != null){
            del.child = ch.child;
            del.value = ch.value;
            del.sibling = ch.sibling;
        }
        else
            this.child = null;
        return true;
    }

    public boolean removeChild(int index){
        Node f = this.getChild(index);
        if(f == null)
            return false;
        else
            return this.removeChild(f);
    }

    public Node find(int val){
        Node cur = this;
        Node f = null;
        //System.out.println(this.value);
        if(this.equals(null))
            return null;
        if(cur.value == val)
            return cur;
        while(cur.sibling != null){
            cur = cur.sibling;
            if(cur.value == val)
                return cur;
        }
        cur =this;
        if(cur.child != null)
            f = cur.child.find(val);
        if(f != null)
            return f;
        while(cur.sibling != null){
            cur = cur.sibling;
            if(cur.child != null)
                f = cur.child.find(val);
            if(f != null)
                return f;
        }
        return null;
    }
}
