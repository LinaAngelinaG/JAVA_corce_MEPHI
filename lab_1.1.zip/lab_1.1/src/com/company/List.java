package com.company;

public class List {
    //добавить деструктор
    private elem head;
    private elem tail;
    int count; //будем сразу считать размер(длину)

    public class elem{
        public int data;
        public elem next;
        public elem prev;
        elem(int a) { //конструктор
            data = a;
        }
    }

    public List(){ //конструктор
        head = null;
        tail = null;
        count = 0;
    }

    public void add(int a){
        elem el = new elem(a);
        if(isEmpty())
            head = el;
        else{
            if(tail == null)
                tail = el;
            else
                tail.next = el;
        }
        tail =el;
        count++;
    }

    public void add(int a, int index){
        elem curr = head;
        int cur = 0;
        if(index == count)
            add(a);
        else if (index < count){
            while(cur < index){
                curr = curr.next;
                cur++;
            }
            elem node = new elem(a);
            node.next = curr.next;
            curr.next.prev = node;
            node.prev = curr;
            curr.next = node;
            count++;
        }
        else
            System.out.println("Error! Too high index!");

    }

    public elem get(int index){
        elem curr = head;
        int cur = 0;
        if(index == count)
            return tail;
        else if (index < count){
            while(cur < index){
                curr = curr.next;
                cur++;
            }
            return curr;
        }
        else
            return null;
    }

    public int indexOf(int a){
        elem curr = head;
        int cur = 0;
        while(curr != null){
            if(curr.data == a)
                return cur;
            curr = curr.next;
            cur++;
        }
        return -1;
    }

    public int size(){
        return count;
    }

    public boolean contains(int a){
        elem curr = head;
        int cur = 0;
        while(curr != null){
            if(curr.data == a)
                return true;
            curr = curr.next;
            cur++;
        }
        return false;
    }

    public void set (int a, int index){
        if(index >= count)
            System.out.println("Impossiple to set with such an index!");
        else{
            elem node = head;
            int cur = 0;
            while(cur < index){
                cur++;
                node = node.next;
            }
            node.data = a;
            System.out.println("The setting is completed!");
        }
    }

    public int remove (int index){
        if(index >= count)
            System.out.println("Impossiple to delete with such an index!");
        else{
            elem node = head;
            int cur = 0;
            while(cur < index){
                cur++;
                node = node.next;
            }
            node.prev.next = node.next;
            if(node.next != null)
                node.next.prev = node.prev;
            node = null;
            System.out.println("The deleting is completed!");
            count--;
            return 1;
        }
        return -1;
    }

    public boolean isEmpty(){
        return head == null;
    }

    public void print(){
        elem curr = head;
        while(curr != null){
            System.out.print(curr.data + "  ");
            curr = curr.next;
        }
        System.out.println();
    }
}


/* while(current != null){
            s++;
            if(current.child != null)
                s += current.child.size();
            current = current.sibling;
            if(current!=null && current.child != null)
                s += current.child.size();
        }
        return s;*/
