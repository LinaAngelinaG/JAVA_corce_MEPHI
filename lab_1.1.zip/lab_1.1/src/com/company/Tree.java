package com.company;

public class Tree {
    /* Операции
  - Добавить ребенка:                        public void addChild(Node value);   vvvvv
  - Удалить ребенка                          public boolean removeChild(Node value);     vvvvv
                                             public boolean removeChild(int index);     vvvvv
  - Получить ребенка                         public Node getChild(int index);  vvvvv
  - Получить родителя                        public Node getParent(); (если родителя нет, тогда null)  vvvvv
  - Получить путь от ребенка до родителя:    public List path();   vvvvv
  - Получить поддерево от какой-нибудь узла: public Tree subtree();    vvvvv
  - Преобразовать дерево в список:           public List toList();     vvvvv
  - Найти узел                               public Node find(Object value);    vvvvv
  - Найти общего родителя между узлами       public Node findParent(Node another);   vvvvv
  - Количество узлов:                        public int size();   vvvvv
  - Пустое дерево или нет:                   public boolean isEmpty();  vvvvv
Node - это класс узел, который используется в Tree. Его требуется сделать. API для этого класса оставляется на ваше усмотрение.
Исключения не используются. В случае неопределенности - вернуть null.
List используется тот, что был сделан как первое задание.
*/

    Node tree;

    Tree(){
        tree = null;
    }
    Tree(Node v){
        tree = v;
    }

    public boolean isEmpty(){
        return this.tree == null;
    }

    public List toList(){
        List list = new List();
        list = makelist(this.tree, list);
        if(list.isEmpty())
            list =null;
        return list;
    }

    private List makelist(Node m, List list){
        Node tr = m;
        if(tr == null)
            return list;
        else
            list.add(tr.value);
        if(tr.child != null){
            list = makelist(tr.child, list);
        }
        if(tr.sibling != null){
            list = makelist(tr.sibling, list);
        }
        return list;
    }

    public Node find(int value){
        Node cur;
        cur = tree.find(value);
        return cur;
    }
}
